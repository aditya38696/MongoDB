const { ObjectId } = require('mongodb');
const { getDB } = require('../config/db');
const Note = require('../models/Note');

// Get all notes
async function getAllNotes(req, res) {
  try {
    const db = getDB();
    const notesCollection = db.collection('notes');
    const notes = await notesCollection.find({}).toArray();
    res.status(200).json(notes);
  } catch (error) {
    console.error('Error fetching notes:', error);
    res.status(500).json({ error: 'Failed to fetch notes' });
  }
}

// Get note by ID
async function getNoteById(req, res) {
  try {
    const { id } = req.params;
    
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'Invalid note ID' });
    }
    
    const db = getDB();
    const notesCollection = db.collection('notes');
    const note = await notesCollection.findOne({ _id: new ObjectId(id) });
    
    if (!note) {
      return res.status(404).json({ error: 'Note not found' });
    }
    
    res.status(200).json(note);
  } catch (error) {
    console.error('Error fetching note:', error);
    res.status(500).json({ error: 'Failed to fetch note' });
  }
}

// Create a new note
async function createNote(req, res) {
  try {
    const { title, content } = req.body;
    
    if (!title || !content) {
      return res.status(400).json({ error: 'Title and content are required' });
    }
    
    const note = new Note(title, content);
    const db = getDB();
    const notesCollection = db.collection('notes');
    const result = await notesCollection.insertOne(note.toObject());
    
    res.status(201).json({ id: result.insertedId, ...note.toObject() });
  } catch (error) {
    console.error('Error creating note:', error);
    res.status(500).json({ error: 'Failed to create note' });
  }
}

// Update a note
async function updateNote(req, res) {
  try {
    const { id } = req.params;
    const { title, content } = req.body;
    
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'Invalid note ID' });
    }
    
    if (!title || !content) {
      return res.status(400).json({ error: 'Title and content are required' });
    }
    
    const db = getDB();
    const notesCollection = db.collection('notes');
    const result = await notesCollection.updateOne(
      { _id: new ObjectId(id) },
      { $set: { title, content, updatedAt: new Date() } }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ error: 'Note not found' });
    }
    
    res.status(200).json({ message: 'Note updated successfully' });
  } catch (error) {
    console.error('Error updating note:', error);
    res.status(500).json({ error: 'Failed to update note' });
  }
}

// Delete a note
async function deleteNote(req, res) {
  try {
    const { id } = req.params;
    
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'Invalid note ID' });
    }
    
    const db = getDB();
    const notesCollection = db.collection('notes');
    const result = await notesCollection.deleteOne({ _id: new ObjectId(id) });
    
    if (result.deletedCount === 0) {
      return res.status(404).json({ error: 'Note not found' });
    }
    
    res.status(200).json({ message: 'Note deleted successfully' });
  } catch (error) {
    console.error('Error deleting note:', error);
    res.status(500).json({ error: 'Failed to delete note' });
  }
}

module.exports = {
  getAllNotes,
  getNoteById,
  createNote,
  updateNote,
  deleteNote
};