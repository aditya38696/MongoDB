// Script to delete a note atomically
// Usage: mongo notesdb mongo-scripts/delete-note.js

// Connect to the notesdb database
db = db.getSiblingDB('notesdb');

// Delete a note (replace "NOTE_ID_HERE" with actual note ID)
var noteId = ObjectId("NOTE_ID_HERE");

var result = db.notes.deleteOne({ _id: noteId });

if (result.deletedCount > 0) {
  print("Note deleted successfully!");
} else {
  print("Note not found or already deleted.");
}