// Script to insert a new note atomically
// Usage: mongo notesdb mongo-scripts/insert-note.js

// Connect to the notesdb database
db = db.getSiblingDB('notesdb');

// Insert a new note
db.notes.insertOne({
  title: "Sample Note from MongoDB Shell",
  content: "This note was created directly from MongoDB shell script.",
  createdAt: new Date(),
  updatedAt: new Date()
});

print("Note inserted successfully!");