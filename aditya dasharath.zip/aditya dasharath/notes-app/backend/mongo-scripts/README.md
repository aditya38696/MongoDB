# MongoDB Shell Scripts for Notes App

This directory contains MongoDB shell scripts for performing CRUD operations on the notes collection directly from the MongoDB shell.

## Prerequisites

1. Make sure MongoDB is installed and running on your system
2. The notes database (`notesdb`) should exist
3. The notes collection should exist (will be created automatically when you insert the first note)

## Usage

To run any of these scripts, use the MongoDB shell command:

```bash
mongo notesdb mongo-scripts/script-name.js
```

Replace `script-name.js` with the actual script filename.

## Available Scripts

### 1. Insert a Note
```bash
mongo notesdb mongo-scripts/insert-note.js
```

### 2. Update a Note
First, replace `"NOTE_ID_HERE"` with the actual ObjectId of the note you want to update in `update-note.js`, then run:
```bash
mongo notesdb mongo-scripts/update-note.js
```

### 3. Delete a Note
First, replace `"NOTE_ID_HERE"` with the actual ObjectId of the note you want to delete in `delete-note.js`, then run:
```bash
mongo notesdb mongo-scripts/delete-note.js
```

### 4. Find All Notes
```bash
mongo notesdb mongo-scripts/find-notes.js
```

## Getting Note IDs

To get the ObjectId of a note, you can use the find script or run this command in the MongoDB shell:
```javascript
use notesdb
db.notes.find({}, {_id: 1})
```

This will show all note IDs in the collection.