// Script to update a note atomically
// Usage: mongo notesdb mongo-scripts/update-note.js

// Connect to the notesdb database
db = db.getSiblingDB('notesdb');

// Update a note (replace "NOTE_ID_HERE" with actual note ID)
var noteId = ObjectId("NOTE_ID_HERE");

db.notes.updateOne(
  { _id: noteId },
  { 
    $set: { 
      title: "Updated Title from MongoDB Shell",
      content: "This note was updated directly from MongoDB shell script.",
      updatedAt: new Date()
    }
  }
);

print("Note updated successfully!");