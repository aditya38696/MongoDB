class Note {
  constructor(title, content, createdAt = new Date(), updatedAt = new Date()) {
    this.title = title;
    this.content = content;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;
  }

  // Convert note object to plain object for MongoDB
  toObject() {
    return {
      title: this.title,
      content: this.content,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
  }

  // Create a note from MongoDB document
  static fromDocument(doc) {
    const note = new Note(doc.title, doc.content, doc.createdAt, doc.updatedAt);
    note._id = doc._id;
    return note;
  }
}

module.exports = Note;