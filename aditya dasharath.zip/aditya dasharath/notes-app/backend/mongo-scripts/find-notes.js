// Script to find all notes
// Usage: mongo notesdb mongo-scripts/find-notes.js

// Connect to the notesdb database
db = db.getSiblingDB('notesdb');

// Find all notes
var notes = db.notes.find();

// Print all notes
while (notes.hasNext()) {
  var note = notes.next();
  print("Title: " + note.title);
  print("Content: " + note.content);
  print("Created: " + note.createdAt);
  print("Updated: " + note.updatedAt);
  print("------------------------");
}

print("Total notes found: " + db.notes.count());